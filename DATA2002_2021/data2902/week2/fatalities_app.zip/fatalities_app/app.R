#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(tidyverse)
fdata = readxl::read_excel("ardd_fatalities_jun2021.xlsx",
                           sheet = 2,
                           skip = 4,
                           na = c("","-9"),
                           guess_max = 1e6) %>%
    janitor::clean_names()



# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("Fatalities"),

    # Sidebar with a slider input for number of bins
    sidebarLayout(
        sidebarPanel(


            selectInput(inputId = "year_selection",
                        label = "Select year:",
                        choices = 1989:2021,
                        selected = 2019,
                        multiple = TRUE)
        ),

        # Show a plot of the generated distribution
        mainPanel(
           plotOutput("fatalitiesPlot"),
           verbatimTextOutput("chisq_test")
        )
    )
)



# Define server logic required to draw a histogram
server <- function(input, output) {


    final_data = reactive({
        fdata %>%
            filter(year %in% input$year_selection) %>%
            group_by(month) %>%
            count()
    })

    output$fatalitiesPlot <- renderPlot({

        final_data() %>%
            ggplot() +
            aes(x = month, y = n) +
            # geom_bar(stat='identity')
            geom_col() +
            labs(title = paste(input$year_selection, collapse = ", "))

    })

    output$chisq_test = renderPrint({

        final_data() %>%
            pull(n) %>%
            chisq.test()

    })

}

# Run the application
shinyApp(ui = ui, server = server)
